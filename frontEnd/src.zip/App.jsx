import  React from 'react'
import SignUpPage from './Pages/PagesJSX/SignUpPage.jsx'
import LoginPage from './Pages/PagesJSX/LoginPage.jsx'
function App() {
  return (
  // <SignUpPage/>
  <LoginPage/>

)
}

export default App
