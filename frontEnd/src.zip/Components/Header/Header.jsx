import React from "react";
import logo from "../assets/logo.jpg";

const Header = ({ isLoggedIn, onSignOut }) => {
  return (
    <>
      <header className="header">
        <div className="logo-container">
          <img src={logo} alt="Logo" />
        </div>

        <div className="button-container">
          {!isLoggedIn ? (
            <>
              <button className="signup-button button">Sign Up</button>
              <button className="login-button button">Log In</button>
            </>
          ) : (
            <button className="signout-button button" onClick={onSignOut}>
              Sign Out
            </button>
          )}
        </div>
      </header>

      <style jsx>{`
        .header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 10px 20px;
          background-color: #c2bf98;
        }

        .logo-container {
          flex: 1;
        }

        .logo-container img {
          height: 85px;
        }

        .button-container {
          display: flex;
          gap: 10px;
        }

        .button {
          padding: 10px 20px;
          border-radius: 4px;
          cursor: pointer;
          transition: background-color 0.3s ease, color 0.3s ease;
          font-weight: bold;
          color: #fff;
        }

        .signup-button {
          background-color: #886aa6;
          border: none;
        }

        .signup-button:hover {
          background-color: rgba(136, 106, 166, 0.8);
        }

        .signup-button:active {
          background-color: rgba(136, 106, 166, 0.6);
        }

        .login-button {
          background-color: transparent;
          border: 2px solid #886aa6;
        }

        .login-button:hover {
          background-color: rgba(136, 106, 166, 0.8);
          border-color: #886aa6;
        }

        .login-button:active {
          border-color: rgba(136, 106, 166, 0.6);
        }

        .signout-button {
          background-color: #886aa6;
          border: none;
        }

        .signout-button:hover {
          background-color: #ff8673;
        }

        .signout-button:active {
          background-color: #ffab9f;
        }
      `}</style>
    </>
  );
};

export default Header;
