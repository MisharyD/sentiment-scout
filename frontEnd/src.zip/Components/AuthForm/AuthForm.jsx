import React, { useState } from "react";
import "./auth-form.css";
// import Input from "./Input.jsx";
import AuthInput from "../AuthInput/AuthInput.jsx";
import AuthHeader from "../AuthHeader/AuthHeader.jsx";
import AuthButton from "../AuthButton/AuthButton.jsx";
import AuthOption from "../AuthOptions/AuthOptions.jsx";
function Form({formType}) {
  const formStyle = formType === 'signup' 
  ? { borderTopRightRadius: '15px', borderBottomRightRadius: '15px' } 
  : { borderTopLeftRadius: '15px', borderBottomLeftRadius: '15px' };

  return (

      <div id='form' style={formStyle}>
      {formType === 'signup' && (<AuthInput label='Username' name='username' type='text' placeholder='Enter your Username'/>)}

      {formType === 'signup' ? ( <AuthHeader text="Create your Account" />) : ( <AuthHeader text="Log in to your Account" /> )}

      <AuthInput label='Username' name='Username' type='Username' placeholder='Enter your Username'/>
      <AuthInput label='Email' name='email' type='email' placeholder='Enter your email'/>
      <AuthInput label='Password' name='password' type='password' placeholder='Enter your password'/>

      {formType === 'signup' && (<AuthInput label='Confirm Password' name='confirmPassword' type='password' placeholder='Confirm your password'/>)}

      {formType === 'signup' ? ( <AuthButton text='Create Account' />) : (<AuthButton text='Login' />)}

  
      {formType === 'signup' ? ( <AuthOption ctaPrompt='Already have an account?' prompt='Sign-In' /> ) : (<AuthOption ctaPrompt="Don't have an account?" prompt='Sign-Up' />)}
      </div>
  );
}

export default Form;
