import React from "react";
import './auth-options.css'

function AuthOption(props){
    return (
    <div id='auth-option'>
        <h6 id='or'>-OR-</h6>
        <p id='cta-prompt'>{props.ctaPrompt} <a href='#' id='prompt'>{props.prompt}</a></p>

    </div>)
}

export default AuthOption