import React from "react";
import "./Auth-input.css";

function AuthInput(props) {
  return (
    <div className="input-container">
        <label htmlFor={props.name} className='auth-label'>
        {props.label}
        </label>
        <input className='auth-input' id={props.name} name={props.name} type={props.type} placeholder={props.placeholder}/>
    </div>
  )
   
}

export default AuthInput;
